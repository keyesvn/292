document.addEventListener('DOMContentLoaded', initPopup);

const proxyInput = document.getElementById('proxyString');
const saveBtn = document.getElementById('save');
const disableBtn = document.getElementById('disable');

saveBtn.addEventListener('click', saveProxy);
disableBtn.addEventListener('click', toggleProxy);

async function initPopup() {
    try {
        const data = await chrome.storage.local.get([
            'proxy',
            'proxyEnabled'
        ]);

        const proxy = data.proxy;
        const enabled = data.proxyEnabled !== false;

        if (proxy && proxy.ip && proxy.port) {
            proxyInput.value = buildProxyString(proxy);
        }

        updateUI(enabled && !!(proxy && proxy.ip));

    } catch (err) {
        alert(`Lỗi đọc cấu hình: ${err.message}`);
    }
}

function buildProxyString(proxy) {
    let result = `${proxy.ip}:${proxy.port}`;

    if (proxy.user && proxy.pass) {
        result += `:${proxy.user}:${proxy.pass}`;
    }

    return result;
}

function updateUI(isActive) {
    const dot = document.getElementById('statusIndicator');
    const label = document.getElementById('toggleLabel');

    if (isActive) {
        dot.classList.add('active');
        if (label) label.textContent = 'Tắt Proxy';
    } else {
        dot.classList.remove('active');
        if (label) label.textContent = 'Bật lại Proxy';
    }
}

function parseProxyString(raw) {
    const value = raw.trim();

    if (!value) {
        throw new Error('Vui lòng nhập proxy!');
    }

    const parts = value.split(':');

    if (parts.length < 2) {
        throw new Error('Định dạng hợp lệ: IP:Port hoặc IP:Port:User:Pass');
    }

    const ip = parts[0].trim();
    const portRaw = parts[1].trim();
    const port = Number(portRaw);

    if (!ip) {
        throw new Error('IP không được để trống');
    }

    if (!Number.isInteger(port) || port < 1 || port > 65535) {
        throw new Error('Port không hợp lệ');
    }

    return {
        scheme: 'http',
        ip,
        port: String(port),
        user: parts[2] ? parts[2].trim() : '',
        pass: parts.length >= 4 ? parts.slice(3).join(':') : ''
    };
}

async function sendReloadMessage() {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: 'reload_proxy' }, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
                return;
            }

            if (response?.status === 'error') {
                reject(new Error(response.message));
                return;
            }

            resolve(response);
        });
    });
}

async function saveProxy() {
    try {
        const proxy = parseProxyString(proxyInput.value);

        await chrome.storage.local.set({
            proxy,
            proxyEnabled: true
        });

        await sendReloadMessage();

        window.close();

    } catch (err) {
        alert(err.message);
    }
}

async function toggleProxy() {
    try {
        const data = await chrome.storage.local.get([
            'proxy',
            'proxyEnabled'
        ]);

        const currentlyEnabled = data.proxyEnabled !== false;

        await chrome.storage.local.set({
            proxyEnabled: !currentlyEnabled
        });

        await sendReloadMessage();

        window.close();

    } catch (err) {
        alert(`Lỗi bật/tắt proxy: ${err.message}`);
    }
}
