let currentProxy = null;
let authRetryMap = new Map();

function isValidProxy(proxy) {
    if (!proxy || !proxy.ip || !proxy.port) return false;

    const port = Number(proxy.port);

    return (
        Number.isInteger(port) &&
        port >= 1 &&
        port <= 65535
    );
}

function normalizeProxy(proxy) {
    return {
        scheme: proxy.scheme || 'http',
        ip: String(proxy.ip || '').trim(),
        port: String(proxy.port || '').trim(),
        user: String(proxy.user || '').trim(),
        pass: String(proxy.pass || '')
    };
}

async function setBadge(enabled) {
    await chrome.action.setBadgeText({
        text: enabled ? 'ON' : 'OFF'
    });

    await chrome.action.setBadgeBackgroundColor({
        color: enabled ? '#4CAF50' : '#f44336'
    });
}

async function applyProxySettings(proxy) {
    const p = normalizeProxy(proxy);

    if (!isValidProxy(p)) {
        throw new Error('Proxy không hợp lệ');
    }

    const config = {
        mode: 'fixed_servers',
        rules: {
            singleProxy: {
                scheme: p.scheme,
                host: p.ip,
                port: Number(p.port)
            },
            bypassList: [
                'localhost',
                '127.0.0.1',
                '<local>'
            ]
        }
    };

    await chrome.proxy.settings.set({
        value: config,
        scope: 'regular'
    });
}

async function clearProxySettings() {
    await chrome.proxy.settings.clear({
        scope: 'regular'
    });
}

async function loadProxy() {
    try {
        const data = await chrome.storage.local.get([
            'proxy',
            'proxyEnabled'
        ]);

        const enabled = data.proxyEnabled !== false;
        const proxy = normalizeProxy(data.proxy || {});

        if (enabled && isValidProxy(proxy)) {
            currentProxy = proxy;
            authRetryMap.clear();

            await applyProxySettings(proxy);
            await setBadge(true);

            console.log('[292] Proxy applied:', `${proxy.ip}:${proxy.port}`);
        } else {
            currentProxy = null;
            authRetryMap.clear();

            await clearProxySettings();
            await setBadge(false);

            console.log('[292] Proxy disabled.');
        }
    } catch (err) {
        console.error('[292] loadProxy error:', err);

        currentProxy = null;
        await clearProxySettings();
        await setBadge(false);
    }
}

chrome.runtime.onInstalled.addListener(loadProxy);
chrome.runtime.onStartup.addListener(loadProxy);

chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;

    if (changes.proxy || changes.proxyEnabled) {
        loadProxy();
    }
});

chrome.webRequest.onAuthRequired.addListener(
    (details, callback) => {
        try {
            if (!details.isProxy) {
                callback({});
                return;
            }

            if (!currentProxy || !currentProxy.user || !currentProxy.pass) {
                callback({});
                return;
            }

            const key = `${details.requestId}:${details.challenger?.host || ''}`;
            const retryCount = authRetryMap.get(key) || 0;

            if (retryCount >= 1) {
                authRetryMap.delete(key);
                callback({ cancel: true });
                return;
            }

            authRetryMap.set(key, retryCount + 1);

            callback({
                authCredentials: {
                    username: currentProxy.user,
                    password: currentProxy.pass
                }
            });

        } catch (err) {
            console.error('[292] Auth error:', err);
            callback({});
        }
    },
    {
        urls: ['<all_urls>']
    },
    ['asyncBlocking']
);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.action) return;

    if (msg.action === 'reload_proxy') {
        loadProxy()
            .then(() => {
                sendResponse({
                    status: 'ok'
                });
            })
            .catch((err) => {
                sendResponse({
                    status: 'error',
                    message: err.message
                });
            });

        return true;
    }
});
