(async () => {
    const $ = (id) => document.getElementById(id);
    const params = new URLSearchParams(window.location.search);

    const ip = (params.get('ip') || '').trim();
    const portRaw = (params.get('port') || '').trim();
    const user = (params.get('user') || '').trim();
    const pass = params.get('pass') || '';

    const proxyInfo = $('proxyInfo');
    const status = $('status');

    function setStatus(type, text) {
        status.innerHTML = `
            <div class="dot ${type}"></div>
            <span>${text}</span>
        `;
    }

    if (ip && portRaw) {
        proxyInfo.textContent = user
            ? `${ip}:${portRaw} (auth: ${user})`
            : `${ip}:${portRaw}`;
    } else {
        proxyInfo.textContent = 'Không có thông số proxy trong URL';
    }

    const port = Number(portRaw);

    if (!ip || !Number.isInteger(port) || port < 1 || port > 65535) {
        setStatus('error', 'Thiếu IP hoặc port không hợp lệ!');
        return;
    }

    try {
        const proxy = {
            scheme: 'http',
            ip,
            port: String(port),
            user,
            pass
        };

        await chrome.storage.local.set({
            proxy,
            proxyEnabled: true
        });

        const response = await new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: 'reload_proxy' }, (res) => {
                if (chrome.runtime.lastError) {
                    resolve({
                        status: 'error',
                        message: chrome.runtime.lastError.message
                    });
                    return;
                }

                resolve(res);
            });
        });

        if (response?.status === 'error') {
            setStatus('error', `Lỗi apply proxy: ${response.message}`);
            return;
        }

        setStatus('success', 'Đã cấu hình proxy thành công! Đang đóng tab...');

        setTimeout(() => {
            window.close();
        }, 1500);

    } catch (err) {
        setStatus('error', `Lỗi: ${err.message}`);
        console.error('[292ProxySwitcher] Config error:', err);
    }
})();
